from rest_framework .views import APIView
from django.http import JsonResponse
from rest_framework import status
from .models import *
from .serializer import *

class customerPost(APIView):
    def post(self,request):
        serializer = CustomerdbSerializer(data=request.data)
        if serializer.is_valid():
            User_name = serializer.data["User_name"]
            Mobile_number = serializer.data["Mobile_number"]
            email = serializer.data["email"]
            password = serializer.data["password"]


            Customerdb.objects.create(User_name=User_name,Mobile_number=Mobile_number,email=email,password=password)
            print(Customerdb)

            message = {"message": " signup sucessfully"}
            return JsonResponse(message,status=status.HTTP_201_CREATED,safe=False)
        else:
            message = {"message": " signup unsucessfully"}
            return JsonResponse(serializer.errors,status=status.HTTP_400_BAD_REQUEST,safe=False)


class customerget(APIView):
    def get(self,request):
        result =list(Customerdb.objects.filter().values())
        return JsonResponse(result,status=status.HTTP_200_OK,safe=False)



class loginGet(APIView):
    def post(self,request):
        serializer = loginSerializer(data=request.data)
        if serializer.is_valid():
            User_name = serializer.data["User_name"]
            password = serializer.data["password"]


            Customerdb.objects.create(User_name=User_name,password=password)
            print(Customerdb)

            message = {"message": " signup sucessfully"}
            return JsonResponse(message,status=status.HTTP_201_CREATED,safe=False)
        else:
            message = {"message": " signup unsucessfully"}
            return JsonResponse(serializer.errors,status=status.HTTP_400_BAD_REQUEST,safe=False)









