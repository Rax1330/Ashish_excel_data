from django.db import models

class Customerdb(models.Model):
    User_name = models.CharField(max_length=100,unique=True)
    Mobile_number = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)




