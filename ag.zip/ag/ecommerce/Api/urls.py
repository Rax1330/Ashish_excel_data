from django.urls import path
from.import views

urlpatterns = [
    path("api/v1/customer/create/", views.customerPost.as_view()),  # customer
    path("api/v1/customer/list/", views.loginGet.as_view()),  # admin
    path("api/v1/customer/get/", views.customerget.as_view()),

]

