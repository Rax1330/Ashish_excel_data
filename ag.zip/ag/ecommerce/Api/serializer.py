from rest_framework import serializers

class CustomerdbSerializer(serializers.Serializer):
    User_name = serializers.CharField(max_length=100)
    email = serializers.EmailField()
    Mobile_number = serializers.CharField(max_length=15)
    password = serializers.CharField(max_length=20)


class loginSerializer(serializers.Serializer):
    User_name = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=20)






